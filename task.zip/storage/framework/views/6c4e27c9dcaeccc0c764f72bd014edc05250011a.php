<?php $__env->startSection('content'); ?>

<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="col-md-12">
<div class="row">

<?php if(auth()->user()->role=='siswa'): ?>
	<form class="navbar-form navbar-left" action="/kerjakan" method="get">
						<div class="input-group">
							<input name="token" type="text" value="" class="form-control" placeholder="Masukkan Nomor Token Ujian">
							<span class="input-group-btn">
									<button type="submit" class="btn btn-primary">Go</button>
									</span>

					</form>
					<?php endif; ?>


</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>