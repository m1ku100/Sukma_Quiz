<?php $__env->startSection('content'); ?>
<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="row">
<div class="col-md-12">
<div class="panel">	
<div class="panel-heading">
	<h3 class="panel-title">Data Soal</h3>
	<div class="right">
	<button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><i class="lnr lnr-plus-circle"></i>
	<p> Tambah Soal </p> </button>
	</div>
</div>
<div class="panel-body">
	<table class="table table-hover">
	<thead>
	<tr>
		<th>Pelajaran</th>
		<th>Kelas</th>
		<th>Jurusan</th>
		<th>Soal</th>
		<th>Pilihan A</th>
		<th>Pilihan B</th>
		<th>Pilihan C</th>
		<th>Pilihan D</th>
		<th>Pilihan E</th>
		<th>Kunci Jawaban</th>
		<th>Aksi</th>
	</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $data_soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($soal->pelajaran); ?></td>
			<td><?php echo e($soal->kelas); ?></td>
			<td><?php echo e($soal->jurusan); ?></td>
			<td><?php echo e($soal->soal); ?></td>
			<td><?php echo e($soal->pilihan_a); ?></td>
			<td><?php echo e($soal->pilihan_b); ?></td>
			<td><?php echo e($soal->pilihan_c); ?></td>
			<td><?php echo e($soal->pilihan_d); ?></td>
			<td><?php echo e($soal->pilihan_e); ?></td>
			<td><?php echo e($soal->kunci_jawaban); ?></td>
			<td>
			<a href="/soal/<?php echo e($soal->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
			<a href="/soal/<?php echo e($soal->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin mau dihapus?')">Delete</a>
			</td>
			</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
	</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
	<div class="modal-content">
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<div class="modal-body">
	<form action="/soal/create" method="POST">
		<?php echo e(csrf_field()); ?>

	<div class="form-group">
		<label for="exampleFormControlSelect1">Pilih Pelajaran</label>
		<select name="pelajaran" class="form-control" id="exampleFormControlSelect1">
			<option>Matematika</option>
			<option>Bahasa Indonesia</option>
			<option>Bahasa Ingris</option>
		</select>
	</div>
	<div class="form-group">
		<label for="exampleFormControlSelect1">Pilih Kelas</label>
		<select name="kelas" class="form-control" id="exampleFormControlSelect1">
			<option>10</option>
			<option>11</option>
			<option>12</option>
		</select>
	</div>
	<div class="form-group">
		<label for="exampleFormControlSelect1">Pilih Jurusan</label>
		<select name="jurusan" class="form-control" id="exampleFormControlSelect1">
			<option>IPA</option>
			<option>IPS</option>
			<option>AGAMA</option>
		</select>
	</div>
	<div class="form-group">
		<label for="exampleFormControlTextarea1">Soal</label>
		<textarea name="soal" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	</div>						
	<div class="form-group">
		<label for="exampleFormControlTextarea1">Pilihan A</label>
		<textarea name="pilihan_a" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	</div>
	<div class="form-group">
		<label for="exampleFormControlTextarea1">Pilihan B</label>
		<textarea name="pilihan_b" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	</div>
	<div class="form-group">
		<label for="exampleFormControlTextarea1">Pilihan C</label>
		<textarea name="pilihan_c" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	</div>
	<div class="form-group">
		<label for="exampleFormControlTextarea1">Pilihan D</label>
		<textarea name="pilihan_d" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	</div>
	<div class="form-group">
		<label for="exampleFormControlTextarea1">Pilihan E</label>
		<textarea name="pilihan_e" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	</div>
	<div class="form-group">
		<label for="exampleFormControlTextarea1">Kunci Jawaban</label>
		<textarea name="kunci_jawaban" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	</div>
</div>
<div class="modal-footer">
	<button type="button" class="btn btn-secondary" data-dismiss="modal"> Close </button>
	<button type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>