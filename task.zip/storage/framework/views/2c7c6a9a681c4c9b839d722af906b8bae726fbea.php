<div id="sidebar-nav" class="sidebar">
	<div class="sidebar-scroll">
		<nav>
			<ul class="nav">
			<li><a href="/" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
			<li><a href="/siswa" class=""><i class="lnr lnr-user"></i> <span>siswa</span></a></li>
			</ul>
		</nav>
	</div>
</div>