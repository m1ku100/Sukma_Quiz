<div id="sidebar-nav" class="sidebar">
	<div class="sidebar-scroll">
		<nav>
			<ul class="nav">
			<li><a href="/" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
			<?php if(auth()->user()->role=='admin'): ?>
			<li>
				<a href="#subPages" data-toggle="collapse" class="collapsed"><i class="lnr lnr-users"></i> <span>Manajemen User</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
				<div id="subPages" class="collapse ">
					<ul class="nav">
						<li><a href="/siswa" class="">Siswa</a></li>
						<li><a href="/guru" class="">Guru</a></li>
					</ul>
				</div>
			</li>
			<li><a href="/soal" class=""><i class="lnr lnr-user"></i> <span>Soal</span></a></li>
			<li><a href="/kerjakan" class=""><i class="lnr lnr-user"></i> <span>kerjakan</span></a></li>
			<li><a href="/mapel" class=""><i class="lnr lnr-user"></i> <span>Mata Pelajaran</span></a></li>
			<li><a href="/kelas" class=""><i class="lnr lnr-user"></i> <span>Kelas</span></a></li>
			<li><a href="/nilai" class=""><i class="lnr lnr-user"></i> <span>Nilai</span></a></li>
			<?php endif; ?>
			<?php if(auth()->user()->role=='guru'): ?>
			<li><a href="/soal" class=""><i class="lnr lnr-user"></i> <span>Soal</span></a></li>
			<li><a href="/nilai" class=""><i class="lnr lnr-user"></i> <span>Nilai</span></a></li>
			<?php endif; ?>
			<?php if(auth()->user()->role=='siswa'): ?>
			<li><a href="/kerjakan" class=""><i class="lnr lnr-user"></i> <span>kerjakan</span></a></li>
			<?php endif; ?>
			</ul>
		</nav>
	</div>
</div>