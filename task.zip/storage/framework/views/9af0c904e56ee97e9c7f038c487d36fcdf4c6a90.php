
<tbody>
    <td>No : <?php echo e($no); ?></td>
    <td>No : <?php echo e($id); ?></td>
    <td>No : <?php echo e($pilihan); ?></td>

</tbody>