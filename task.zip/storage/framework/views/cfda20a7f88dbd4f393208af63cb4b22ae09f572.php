<?php $__env->startSection('content'); ?>

<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="row">
<div class="col-md-8">
<div class="panel">
<div class="panel-heading">
	<h3 class="panel-title"> Kerjakan </h3>
</div>

<div class="panel-body">

	<tbody>
		<?php $no=0; ?>
<?php $__currentLoopData = $data_soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $no++ ;?>
	<tr>
 <FORM ACTION="/kerjakan/simpan_jawaban" METHOD="post" >
	 <?php echo e(csrf_field()); ?>

<input type="hidden" name="soal[]" value="<?php echo e($soal->soal); ?>"></td>
<input type="hidden" name="no[]" value="<?php echo e($no); ?>">
<input type="hidden" name="pelajaran[]" value="<?php echo e($soal->pelajaran); ?>">
<input type="hidden" name="soal_id[]" value="<?php echo e($soal->id); ?>">
<input type="hidden" name="kunci_jawaban[]" value="<?php echo e($soal->kunci_jawaban); ?>">
</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<input type="hidden" name="id_siswa" value="<?php echo e($siswa->id); ?>"/>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<input type="submit" value="Mulai" class="panel-title">
	</tbody>

	<p>

</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>