<?php $__env->startSection('content'); ?>
<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="row">
<div class="col-md-8">
<div class="panel">
<div class="panel-heading">
	<h3 class="panel-title"> Kerjakan </h3>

</div>

<div class="panel-body">

	<tbody>
	<?php $__currentLoopData = $data_soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td></td>
			<td><?php echo e($soal->soal); ?></td>

			<br>
			<br>
   <FORM ACTION="" METHOD="" >


<input type="radio" name="pilihan<?php echo e($soal->soal); ?> " value="radio"><?php echo e($soal->pilihan_a); ?><br>
<input type="radio" name="pilihan<?php echo e($soal->soal); ?> " value="radio"><?php echo e($soal->pilihan_b); ?><br>
<input type="radio" name="pilihan<?php echo e($soal->soal); ?> " value="radio"><?php echo e($soal->pilihan_c); ?><br>
<input type="radio" name="pilihan<?php echo e($soal->soal); ?> " value="radio"><?php echo e($soal->pilihan_d); ?><br>
<input type="radio" name="pilihan<?php echo e($soal->soal); ?> " value="radio"><?php echo e($soal->pilihan_e); ?><br>

			</tr>
			<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">Back</button>
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">Next</button>


</div>
</div>
</div>
<div class="col-md-4">
	<div class="panel">
		<div class="panel-heading">
	<h3 class="panel-title"> Button Soal </h3>

</div>

<div class="panel-body">
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">1</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">2</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">3</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">4</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">5</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">6</button>
	<br>
	<br>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">7</button>
</div>
	</div>
</div>
</div>
</div>
</div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>