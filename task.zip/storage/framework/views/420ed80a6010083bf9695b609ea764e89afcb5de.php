<?php $__env->startSection('content'); ?>

<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="row">
<div class="col-md-8">
<div class="panel">
<div class="panel-heading">
	<h3 class="panel-title"> Kerjakan </h3>
	<div class="col-md-4">
		<p id="demo"></p>
	</div>
</div>

<div class="panel-body">

	<tbody>
<?php $__currentLoopData = $data_soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


	<tr>
<br>
<?php $no=0; $no++ ?>
		<td><?php echo e($no); ?></td>

		<td><?php echo e($soal->soal); ?></td>

		<br>
		<br>
 <form action="/soal_kerjakan/update" METHOD="POST" >
	 <?php echo e(csrf_field()); ?>

<input type="hidden" name="no" value="<?php echo e($no); ?>">
<input type="hidden" name="pelajaran" value="<?php echo e($soal->pelajaran); ?>">
<input type="hidden" name="soal_id" value="<?php echo e($soal->id); ?>">
<input type="hidden" name="kunci_jawaban" value="<?php echo e($soal->kunci_jawaban); ?>">
<input type="radio" name="jawaban" value="<?php echo e($soal->pilihan_a); ?>"><?php echo e($soal->pilihan_a); ?><br>
<input type="radio" name="jawaban" value="<?php echo e($soal->pilihan_b); ?>"><?php echo e($soal->pilihan_b); ?><br>
<input type="radio" name="jawaban" value="<?php echo e($soal->pilihan_c); ?>"><?php echo e($soal->pilihan_c); ?><br>
<input type="radio" name="jawaban" value="<?php echo e($soal->pilihan_d); ?>"><?php echo e($soal->pilihan_d); ?><br>
<input type="radio" name="jawaban" value="<?php echo e($soal->pilihan_e); ?>"><?php echo e($soal->pilihan_e); ?><br>

			</tr>
			<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<input type="hidden" name="id_siswa" value="<?php echo e($siswa->id); ?>"/>

	</tbody>

</tbody>
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="/soal_kerjakan/<?php echo e($soal->nomer); ?>">Next</button>

</forn>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">Back</button>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
<div class="col-md-4">
	<div class="panel">
		<div class="panel-heading">
	<h3 class="panel-title"> Button Soal </h3>

</div>

<div class="panel-body">
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">1</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">2</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">3</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">4</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">5</button>
</div>
	</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>

<script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2021 20:35:38").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = hours + "h "
  + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>