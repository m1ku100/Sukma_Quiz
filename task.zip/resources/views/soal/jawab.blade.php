
<tbody>
    <td>No : {{$no}}</td>
    <td>No : {{$id}}</td>
    <td>No : {{$pilihan}}</td>

</tbody>