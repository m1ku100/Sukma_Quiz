@extends('layouts.master')
@section('content')

<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="row">
<div class="col-md-8">
<div class="panel">
<div class="panel-heading">
	<h3 class="panel-title"> Kerjakan </h3>
	<div class="col-md-4">
		<p id="demo"></p>
	</div>
</div>

<div class="panel-body">

	<tbody>

		<?php $no=0; ?>
@foreach($data_soal_kerjakan as $soal)
<?php $no++ ;?>
	<tr>
<br>
		<td>{{$no}}</td>
		<td>{{$soal->soal}}</td>

		<br>
		<br>
 <form action="{{ url('kerjakan/soal_kerjakan/') }}" METHOD="POST" >
	 {{csrf_field()}}
<!-- <input type="hidden" name="menit" value="" id="menit"> -->
<input type="hidden" name="id" value="{{$soal->id}}">
<input type="hidden" name="soal" value="{{$soal->soal}}">
<input type="hidden" name="nomer" value="{{$soal->nomer}}">
<input type="hidden" name="id_mapel" value="{{$soal->id_mapel}}">
<input type="hidden" name="soal_id" value="{{$soal->id}}">
<input type="hidden" name="kunci_jawaban" value="{{$soal->kunci_jawaban}}">
<input type="radio" name="jawaban" value="{{ $soal->pilihan_a}}">{{ $soal->pilihan_a}}<br>
<input type="radio" name="jawaban" value="{{ $soal->pilihan_b}}">{{ $soal->pilihan_b}}<br>
<input type="radio" name="jawaban" value="{{ $soal->pilihan_c}}">{{ $soal->pilihan_c}}<br>
<input type="radio" name="jawaban" value="{{ $soal->pilihan_d}}">{{ $soal->pilihan_d}}<br>
<input type="radio" name="jawaban" value="{{ $soal->pilihan_e}}">{{ $soal->pilihan_e}}<br>

			</tr>
			<br>
	@endforeach

@foreach($data_siswa as $siswa)

	<input type="hidden" name="id_siswa" value="{{$siswa->id}}"/>
@endforeach
@foreach($data_siswa as $siswa)

@endforeach
</tbody>
			<button type="submit" class="btn btn-primary" name="simpan" value="Submit">
				Next</button>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">Back</button>

</form>

</div>
</div>
</div>
<div class="col-md-4">
	<div class="panel">
		<div class="panel-heading">
	<h3 class="panel-title"> Button Soal </h3>

</div>

<div class="panel-body">
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">1</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">2</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">3</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">4</button>
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><a href="">5</button>
</div>
	</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
@foreach($data_token as $tok1)


<script>

// Get today's date and time
var mulai = new Date().getTime();
// Set the date we're counting down to
var countDownDate = new Date(mulai + {{$tok1->durasi}}*60000).getTime();
// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = hours + "h "
  + minutes + "m " + seconds + "s ";
	document.getElementById("menit").innerHTML = minutes ;
  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
@endforeach
@stop
