@extends('layouts.master')
@section('content')
<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="row">
<div class="col-md-8">
<div class="panel">
<div class="panel-heading">
<form class="navbar-form navbar-left">
					<div class="input-group">
						<input name="cari" type="text" value="" class="form-control" placeholder="Masukkan Nomor Token Ujian">
						<span class="input-group-btn"><button type="button" class="btn btn-primary">Go</button></span>
					</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
@stop
