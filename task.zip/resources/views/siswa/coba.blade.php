extends('layouts.master')

@section('content')
<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="row">
<div class="col-md-12">
<div class="panel">	
<div class="panel-heading">
	<h3 class="panel-title">Data Siswa</h3>
	<div class="right">
	<div class="panel-body">
									<div class="input-group">
										<input class="form-control" type="text">
										<span class="input-group-btn"><button class="btn btn-primary" type="button">Go!</button></span>
									</div>
					
								</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

@stop