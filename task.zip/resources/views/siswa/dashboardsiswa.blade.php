@extends('layouts.master')
@section('content')

<form class="navbar-form navbar-left">
					<div class="input-group">
						<input name="cari" type="text" value="" class="form-control" placeholder="Masukkan Nomor Token Ujian">
						<span class="input-group-btn"><button type="button" class="btn btn-primary">Go</button></span>
					</div>
					<input class="form-control" type="text">
					<span class="input-group-btn"><button class="btn btn-primary" type="button">Lanjut</button></span>
				</div>

@stop
