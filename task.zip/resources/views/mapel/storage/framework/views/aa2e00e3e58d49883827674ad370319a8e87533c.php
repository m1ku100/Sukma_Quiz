 
 <?php $__env->startSection('isi'); ?>
 
 <html>
 <head>
 
  <meta charset="utf-8">
 </head>
 
 <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

          <!-- Search Widget -->
          <div class="card my-4">
            <h5 class="card-header">Login</h5>
            <div class="card-body">
              <div class="row">
		<div class="col-md-12">
			

<form action='login' method="post">
			
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

				<div class="form-group">
					 
					<label for="username">
						Username
					</label>
					<input type="text" class="form-control" id="username" />
				</div>
				<div class="form-group">
					 
					<label for="pass">
						Password
					</label>
					<input type="password" class="form-control" id="pass" />
				</div>
				
				<button type="submit" class="btn btn-primary" name="login" />
					Submit
				</button>
			</form>
		</div>
	</div>
	</div>
	</div>
	
	</body>
</html>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>