<?php $__env->startSection('isi'); ?>
 <!-- Page Content -->
    <div class="container">

      <div class="row">

    <!-- Page Content -->
    <section class="py-5">
   
        <h1>Half Slider by Start Bootstrap</h1>
        <p>The background images for the slider are set directly in the HTML using inline CSS. The rest of the styles for this template are contained within the
          <code>half-slider.css</code>
          file.</p>
      </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutasli', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>