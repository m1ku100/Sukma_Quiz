
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Mari Berlatih Soal - Soal</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('/')); ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('/')); ?>/assets/css/blog-home.css" rel="stylesheet">

  </head>

  <body>
    
  <style type="text/css">
body {
background: url(<?php echo e(url('/')); ?>/assets/img/balu.jpg) no-repeat fixed;
   -webkit-background-size: 100% 100%;
   -moz-background-size: 100% 100%;
   -o-background-size: 100% 100%;
   background-size: 100% 100%;
}
</style>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark navbar-custom fixed-top">
      <div class="container">
        <a class="navbar-brand text-white" style="font-family:verdana">Mari Berlatih Soal - Soal</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
		
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
			 <a href="<?php echo e(url ('/')); ?>/home" class="btn btn-outline-secondary">Home</a>
            </li> <p> &nbsp </p> <p> &nbsp </p> <p> &nbsp </p>
            <li class="nav-item">
               <a href="<?php echo e(url ('/')); ?>/daftar" class="btn btn-outline-secondary">Daftar</a>
            </li> <p> &nbsp </p> <p> &nbsp </p> <p> &nbsp </p>
          </ul>
        </div>
      </div>
    </nav>

	
<?php echo $__env->yieldContent('isi'); ?>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

          <!-- Search Widget -->
          <div class="card my-4">
            <h5 class="card-header">Login</h5>
            <div class="card-body">
              <div class="row">
		<div class="col-md-12">
			
      <form action="loginme" method="post">
       
				<div class="form-group">
					 
					<label for="username">
						Username
					</label>
					<input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autofocus />
				</div>
				<div class="form-group">
					 
					<label for="pass">
						Password
					</label>
					<input type="password" class="form-control" name="pass" value="<?php echo e(old('pass')); ?>" required autofocus />
				</div>
				 <input type="hidden" name="_token" value="<?php echo e(csrf_token ()); ?>">
        
				<button type="submit" class="btn btn-primary" name="login" />
					Submit
				</button>
			</form>
		</div>
	</div>
	</div>
	</div>

          <!-- Side Widget -->
          <div class="card my-4">
            <h5 class="card-header">Seputar Website</h5>
            <div class="card-body">
              Website ini sedikit banyak berguna untuk adik - adik sekolah dasar untuk melatih daya ingat dari pelajaran yang diperoleh di dalam kelas 
			  meskipun hanya memuat 2 mata pelajaran saja .
            </div>
          </div>

        </div>

      </div>
      <!-- /.row -->

	  
    </div>
    <!-- /.container -->

	
	
	
	 </footer>

    <!-- Bootstrap  -->
    <footer class="py-5 bg-dark">
      <footer class="footer text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4 text-white">Lokasi Kampus </h4>
            <p class="lead mb-0 text-white">Universitas Negeri Surabaya
              <br>Jl. Ketintang </p>
          </div>
          <div class="col-md-4 mb-5 mb-lg-0">
            <h4 class="text-uppercase mb-4 text-white">Kontak Kami </h4>
            <p class="lead mb-0 text-white">Email : dinni1002@gmail.com
              <br>NoTelp : 088834345678
			  <br>Alamat : Jl.Petemon 1 no 15</p>
          </div>
          <div class="col-md-4 text-white">
            <h4 class="text-uppercase mb-4 text-white">MBSS</h4>
            <p class="lead mb-0">Sedikit membantu belajar adik adik tingkat sekolah dasar meskipun hanya 2 mata pelajaran
              <a href="http://startbootstrap.com"></a></p>
          </div>
        </div>
      </div>
    </footer>
	</div>
	<br>
	<div class="copyright py-7 text-center text-white">
      <div class="container">
	  <br>
        <small>Copyright &copy; MBBS (Mari Berlatih Soal - Soal) 2018</small>
      </div>
    </div>
	
	
    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo e(url('/')); ?>/assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
