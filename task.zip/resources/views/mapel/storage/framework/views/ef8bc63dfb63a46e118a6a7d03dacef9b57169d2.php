<?php $__env->startSection('isi'); ?>


 <!-- Page Content -->
    <div class="container">
	

		<!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
		  <br>
            <h2 class="section-heading text-uppercase">-Saran Kamu-</h2>
            <h3 class="section-subheading text-muted">Tulis dibawah ini :)</h3>
           <form action="saranhu" method="post"/>
          </div>
        </div>
      </div>
  <fieldset></fieldset>
		<br>
        <div class="row">
          <div class="col-lg-12">
            <form id="contactForm" name="sentMessage" novalidate>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input class="form-control" name="nama" type="text" placeholder="Your Name *" required data-validation-required-message="Please enter your name.">
                    <p class="help-block text-danger"></p>
                  </div>
				  <br>
                  <div class="form-group">
                    <input class="form-control" name="username" type="text" placeholder="Your Username *" required data-validation-required-message="Please enter your Username.">
                    <p class="help-block text-danger"></p>
                  </div>
				  <br>
                  <div class="form-group">
                    <input class="form-control" name="no_telp" type="text" placeholder="Your Phone *" required data-validation-required-message="Please enter your phone number.">
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
				<br>
                <div class="col-md-6">
                  <div class="form-group">
                    <textarea class="form-control" name="pesan"  placeholder="Your Message *" required data-validation-required-message="Please enter a message."></textarea>
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-lg-12 text-center">
                  <div id="success"></div>
				  <br>
                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                  <button id="sarankan" class="btn btn-primary btn-xl text-uppercase" type="submit">Send Message</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
		</div>
	</div>
</div>
<br>
<br>	

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('saran', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>