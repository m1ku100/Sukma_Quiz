<?php $__env->startSection('isi'); ?>

 <div class="container">

 
<h1 class="my-4">Daftar</h1>
	<form action="daftarhu" method="post">
		<div class="form-group">
					 
					<label for="id_user">
						ID USER
					</label>
					<input type="text" class="form-control" name="id_user" />
				</div>
				<div class="form-group">
					 
					<label for="nama_user">
						NAMA USER
					</label>
					<input type="text" class="form-control" name="nama_user" />
				</div>
				<div class="form-group">
					 
					<label for="alamat_user">
						ALAMAT USER
					</label>
					<input type="text" class="form-control" name="alamat_user" />
				</div>
				<div class="form-group">
					 
					<label for="no_telepon">
						NO TELEPON 
					</label>
					<input type="text" class="form-control" name="no_telepon" />
				</div>
				<div class="form-group">
					 
					<label for="username">
						USERNAME
					</label>
					<input type="text" class="form-control" name="username" />
				</div>
				<div class="form-group">
					 
					<label for="pass">
						PASSWORD
					</label>
					<input type="text" class="form-control" name="pass"/>
				</div>
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<button type="submit" class="btn btn-primary" name="daftarkan">
					DAFTAR
				</button>
			</form>
    
	    
      <!-- /.row -->

      <hr>
	  <!-- Call to Action Section -->
      
      </div>
	  
	
	  
	   <?php $__env->stopSection(); ?>


<?php echo $__env->make('daftar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>