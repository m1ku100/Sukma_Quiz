<?php $__env->startSection('isi'); ?>

<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Mari Berlatih Soal - Soal</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a href="#">Kelas 1</a>
            </li>
            <li class="nav-item">
              <a href="#">Kelas 2</a>
            </li>
			<li class="nav-item">
              <a href="#">Kelas 3</a>
            </li>
			<li class="nav-item">
              <a href="#">Kelas 4</a>
            </li>
			<li class="nav-item">
              <a href="#">Kelas 5</a>
            </li>
			<li class="nav-item">
              <a href="#">Kelas 6</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	
	
  <!-- /.row -->

      <hr>
	  <!-- Call to Action Section -->
      
      </div>
	  
	    <?php $__env->stopSection(); ?>
	
	  
<?php echo $__env->make('soal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>