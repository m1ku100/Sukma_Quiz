<?php $__env->startSection('isi'); ?>
 <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

          <h1 class="my-4">Sejarah</h1>

          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top"  src="<?php echo e(url('/')); ?>/assets/img/bhsindo.jpg"/> 
            <div class="card-body">
              <h2 class="card-title">Bahasa Indonesia</h2>
              <p class="card-text">Bahasa Indonesia adalah bahasa Melayu yang dijadikan sebagai bahasa resmi Republik Indonesia dan bahasa persatuan bangsa Indonesia. 
			  Bahasa Indonesia diresmikan penggunaannya setelah Proklamasi Kemerdekaan Indonesia, tepatnya sehari sesudahnya, bersamaan dengan mulai berlakunya konstitusi.</p>
            </div>
            <div class="card-footer text-muted">
            Baca Selengkapnya di 
              <a href="https://freezcha.wordpress.com/2009/09/25/sejarah-bahasa-indonesia/">Sejarah Bahasa Indonesia</a>
            </div>  
          </div>
		
		
          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="<?php echo e(url('/')); ?>/assets/img/bhsjawa.jpg"/> 
            <div class="card-body">
              <h2 class="card-title">Bahasa Jawa</h2>
              <p class="card-text">Bahasa Jawa adalah bahasa yang digunakan penduduk suku bangsa Jawa di Jawa Tengah,Yogyakarta & Jawa Timur. 
			  Selain itu, Bahasa Jawa juga digunakan oleh penduduk yang tinggal beberapa daerah lain seperti di Banten terutama kota Serang, kabupaten Serang, kota Cilegon dan kabupaten Tangerang, 
			  Jawa Barat khususnya kawasan Pantai utara terbentang dari pesisir utara Karawang, Subang, Indramayu, kota Cirebon dan kabupaten Cirebon.</p>
            </div>
            <div class="card-footer text-muted">
			Baca Selengkapnya di 
              <a href="http://ahdi-popos.blogspot.co.id/2014/02/asal-muasal-bahasa-jawa.html">Sejarah Bahasa Jawa</a>
            </div>
            </div>
          </div>
		

          
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>