@extends('layouts.master')
@section('content')
home
@stop
