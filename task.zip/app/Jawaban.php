<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jawaban extends Model
{
    protected $table ='lembar_siswa';

 	public function siswa()
 	{
 		return $this->belongsToMany(Siswa::class);
 	}
  public function soal()
 	{
 		return $this->belongsToMany(Soal::class);
 	}
}
