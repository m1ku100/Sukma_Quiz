<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hasil extends Model
{
    protected $table ='nilai';
 	protected $fillable =['nama','kelas','jurusan','benar','salah','hasil'];
}
