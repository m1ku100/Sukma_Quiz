<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mapel extends Model
{
    protected $table = 'mapel';
    protected $fillable = ['kode','nama', 'semester', 'jurusan'];

    public function mapel()
 	{
 		return $this->belongsToMany(Mapel::class)->withPivot(['nilai']);
 	}
}
