<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Token extends Model
{
  protected $table ='token';
protected $fillable =['id','id_mapel','durasi','jurusan','jumlah_soal','token'];
public function siswa()
{
  return $this->belongsToMany(Siswa::class);
}
public function soal(){
  return $this->belongsTo(Soal::class);
}
}
