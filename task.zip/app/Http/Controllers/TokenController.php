<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TokenController extends Controller
{
      public function index(Request $request)
      {
          $random = Str::random(8);
          if($request->has('cari')){
              $data_token =\App\Token ::where('id_mapel','LIKE','%'.$request->cari.'%')->get();
          }else{
              $data_token = \App\Token ::all();
          }
          return view('token.index',['data_token'=>  $data_token])->with('token',$random);
      }
      public function create(Request $request)
      {
        \App\Token::create($request->all());
        return redirect('/token')->with('sukses','Token Berhasil Ditambahkan');
      }
      Public function edit ($id)
      {
        $token=\App\Token::find($id);
        return view('token/edit',['token'=> $token]);
      }
      public function update(Request $request, $id)
      {
        $token=\App\Token::find($id);
        $token->update($request->all());
        return redirect('/token')->with('sukses','Data Berhasil Diupdate');
      }
       Public function delete ($id)
      {
        $token=\App\Token::find($id);
        $token->delete();
        return redirect('/token')->with('sukses','Data Berhasil Dihapus');
      }

  }
