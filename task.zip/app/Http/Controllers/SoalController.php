<?php

namespace App\Http\Controllers;



use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Jawaban;
use App\Siswa;
use App\User;
use App\Soal;
use App\Token;
class SoalController extends Controller
{
    public function index(Request $request)
    {
    	if($request->has('cari')){
    		$data_soal =\App\Soal::where('mapel','LIKE','%'.$request->cari.'%')->get();
    	}else{
    		$data_soal = \App\Soal::all();
    	}
    	return view('soal.index',['data_soal'=>  $data_soal]);
    }
    public function create(Request $request)
    {
    	\App\Soal::create($request->all());
    	return redirect('/soal')->with('sukses','Data Berhasil Ditambahkan');
    }
    Public function edit ($id)
    {
    	$soal=\App\Soal::find($id);
    	return view('soal/edit',['soal'=> $soal]);
    }
    public function update(Request $request, $id)
    {
    	$soal=\App\Soal::find($id);
    	$soal->update($request->all());
    	return redirect('/soal')->with('sukses','Data Berhasil Diupdate');
    }
     Public function delete ($id)
    {
    	$soal=\App\Soal::find($id);
    	$soal->delete();
    	return redirect('/soal')->with('sukses','Data Berhasil Dihapus');
    }
        Public function kerjakan (Request $request)
        {

            $token =$request->token;

            $data_soal = Soal::inRandomOrder()->limit(10)->get();
            $emailsiswa= auth()->user()->email;
            $data_siswa = siswa::where('siswa.email','=', $emailsiswa)->get();

            if(Token::where('token','=',$token)){
            $data_token = Token::where('token','=',$token)->get();
            return view('soal.kerjakan',['data_soal' => $data_soal, 'data_siswa' => $data_siswa, 'data_token' => $data_token]);
          }
          return redirect('/dashboard')->with('Maaf Token yang anda masukkan sudah tidak berlaku');
        }
    public function simpan_jawaban(Request $request)
    {
      // dd($request);
        $nomer = $request->jumlah;
        for ($x=0 ;$x<$nomer;$x++) {
        $data_soal = DB::table('soal')->paginate(1);
 //insert data laravel biasa
        $tambah = new Jawaban;
        $tambah->nomer = $request->no[$x];
        $tambah->jawaban = "";
        $tambah->soal = $request->soal[$x];
        $tambah->id_siswa = $request->id_siswa;
        $tambah->id_mapel = $request->id_mapel[$x];
        $tambah->soal_id = $request->soal_id[$x];
        $tambah->kunci_jawaban = $request->kunci_jawaban[$x];
        // if($request->jawaban == $request->kunci_jawaban){
        //   $hasil='3';
        // }
        // else{
        //   $hasil='0';
        // }
        $tambah->skor="1";
        $tambah->save();
      }
        $idsiswa= $request->id_siswa;
        $emailsiswa= auth()->user()->email;
        $id = $request->id;
        if (!isset($request->no)) {
          $no=1;
          $lembar_siswa=\App\Soal::find($id);
        	$lembar_siswa->update($request->all());
        }
       else {
            $no=$request->no;
            $no=+1;
            // $lembar_siswa=\App\Soal::find($id);
          	// $lembar_siswa->update($request->all());
        }
  //      echo $request->no;

        $data_soal_kerjakan = Jawaban::join('soal', 'lembar_siswa.soal_id', '=','soal.id')->where('lembar_siswa.id_siswa','=',$idsiswa)
        ->where('lembar_siswa.nomer','=',$no)->paginate(1);
        $data_siswa = siswa::where('siswa.email','=', $emailsiswa)->get();
        $token = $request->token1;
        $data_token = Token::where('token.token','=',$token)->get();
        // dd($data_soal_kerjakan);
        return view('/soal/soal_kerjakan',['data_soal_kerjakan' => $data_soal_kerjakan, 'data_siswa' => $data_siswa, 'data_token' => $data_token]);
      }
      Public function soal_kerjakan2 ()
      {
         $data_soal = Soal::inRandomOrder()->limit(5)->get();
         $emailsiswa= auth()->user()->email;

         $data_siswa = siswa::where('siswa.email','=', $emailsiswa)->get();
         return view('soal.kerjakan',['data_soal' => $data_soal, 'data_siswa' => $data_siswa]);
       }

    // public function token(Request $request){
    //   $token = DB::table('token')->where
    //   return view('/soal/kerjakan');
    // }
}
